exports.enviarDocumento = (req, res) => {
  res.status(201).json({ mensagem: 'Documento enviado com sucesso (simulado)' });
};
