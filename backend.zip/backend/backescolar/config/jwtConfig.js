//guarda chave secrea do JWT

require('dotenv').config();

exports.chaveSecreta = process.env.JWT_SECRET;

