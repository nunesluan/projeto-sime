const express = require('express');
const app = express();
app.use(express.json());

const verificarPermissao = require('./middlewares/verificarPermissao');
const { definirPermissoesUsuario } = require('./controllers/usuarioController');

app.post('/teste/:id', verificarPermissao('gerenciar_permissoes'), definirPermissoesUsuario);

app.listen(3000, () => {
  console.log('Servidor de teste rodando na porta 3000');
});
